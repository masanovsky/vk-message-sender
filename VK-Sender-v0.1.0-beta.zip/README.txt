Masanovskiy VK Sender

A lightweight Windows desktop tool for sending VK messages to selected friends.

Features:

* VK token authorization
* Automatic token extraction from a pasted redirect URL
* Friend list with IDs and online statuses
* Search and online-only filter
* Recipient selection
* Personalized messages using the recipient's first name
* Device-based access control
* Clean dark interface

How to use:

1. Run VK Sender.exe
2. Paste your VK token or full redirect URL into the Token field
3. Load the friend list
4. Select recipients
5. Enter a message
6. Click Start sending

Notes:

* Source code is private
* Token is not included
* Windows only
* Use responsibly and only message people who expect to hear from you
